# <proj-name>

This project was bootrstrapped using [create-react-parcel-project](https://github.com/fa7ad/create-react-parcel-project).

## USAGE

To start the dev server, run:
```
$ yarn start
```

To make a production build, run:
```
$ yarn run build
```
